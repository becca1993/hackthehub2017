package com.example.becca.hackthehubprojectstuff;

/**
 * Created by Becca on 29/04/2017.
 */

public class User {

    int _id;
    String _username, _password;

    public User(){

    }

    public User(int _id, String _username, String _password){

        this._id = _id;
        this._username = _username;
        this._password = _password;



    }

    public User(String _username, String _password){
        this._username =_username;
        this._password = _password;
    }

    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String get_username() {
        return _username;
    }

    public void set_username(String _username) {
        this._username = _username;
    }

    public String get_password() {
        return _password;
    }

    public void set_password(String _password) {
        this._password = _password;
    }
}
