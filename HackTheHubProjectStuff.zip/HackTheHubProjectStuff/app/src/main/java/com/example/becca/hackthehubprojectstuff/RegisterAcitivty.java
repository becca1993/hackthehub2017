package com.example.becca.hackthehubprojectstuff;

import android.content.Intent;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

public class RegisterAcitivty extends AppCompatActivity {

    DatabaseHelper db;
    User user;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register_acitivty);

        Button register, goback;
        final EditText enterNewPass, enterNewUsername, confirmNewPass;



        register = (Button)findViewById(R.id.register);
        goback = (Button)findViewById(R.id.goback);
        enterNewPass = (EditText)findViewById(R.id.enterNewPass);
        enterNewUsername = (EditText)findViewById(R.id.enterNewUsername);
        confirmNewPass = (EditText)findViewById(R.id.confirmNewPass);


        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                final String username = enterNewUsername.getText().toString();
                final String password = enterNewPass.getText().toString();
                final String confirmPass = confirmNewPass.getText().toString();


                if(password.equalsIgnoreCase(confirmPass)){
                    db = new DatabaseHelper(RegisterAcitivty.this);
                    user = new User();
                    user.set_username(username);
                    user.set_password(password);
                    db.addregister(user);

                    Intent intent = new Intent (RegisterAcitivty.this, LoginActivity.class);
                    startActivity(intent);
                }else{

                    Toast toast = Toast.makeText(getApplicationContext(), "Passwords do not match!!", Toast.LENGTH_SHORT); //If both passwords the user has entered don't match, this Toast will appear to tell the user.
                    toast.show(); // Show toast.

                }
            }
        });


        goback.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegisterAcitivty.this, MainActivity.class);
                startActivity(intent);
            }
        });




    }
}
