package com.example.becca.hackthehubprojectstuff;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {
    DatabaseHelper db;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        db = new DatabaseHelper(this);
        final EditText enterUsername, enterPass;
        Button loginButton;

        enterUsername = (EditText)findViewById(R.id.enterUsername);
        enterPass = (EditText)findViewById(R.id.enterPass);
        loginButton = (Button)findViewById(R.id.loginButton);


        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                final String username = enterUsername.getText().toString();
                final String password = enterPass.getText().toString();

               String storedPass = db.getregister(username);

                if (storedPass.equals(password)){
                    Toast toast = Toast.makeText(getApplicationContext(), "Database is working", Toast.LENGTH_SHORT);
                    toast.show();
                }else{
                    Toast toast = Toast.makeText(getApplicationContext(), "Database is not working", Toast.LENGTH_SHORT);
                    toast.show();
                }
            }
        });
    }


}
